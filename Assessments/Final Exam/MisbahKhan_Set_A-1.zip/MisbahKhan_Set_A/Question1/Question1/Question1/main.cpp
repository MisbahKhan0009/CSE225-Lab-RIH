#include <iostream>
#include"pqtype.h"
#include"pqtype.cpp"
using namespace std;

int main()
{

PQType<int> nums;

nums.Enqueue(6);
nums.Enqueue(4);
nums.Enqueue(200);
nums.Enqueue(500);
nums.Enqueue(600);
nums.Enqueue(700);
nums.Enqueue(900);
nums.Enqueue(400);
    return 0;
}
