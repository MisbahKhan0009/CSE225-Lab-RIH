#include <iostream>
#include"graphtype.cpp"

using namespace std;

int main()
{
    GraphType<char> graph;

    graph.AddVertex('A');
    graph.AddVertex('B');
    graph.AddVertex('C');
    graph.AddVertex('D');
    graph.AddVertex('E');

    graph.AddEdge('A','C', 12);
    graph.AddEdge('A','D', 60);
    graph.AddEdge('E','A', 7);
    graph.AddEdge('B','A', 10);
    graph.AddEdge('C','B', 20);
    graph.AddEdge('C','D', 32);

    cout<<graph.InDegree('A')<<endl;

    graph.DepthFirstSearch('B', 'D');
    cout<<endl;

    if (graph.EdgeFound('B', 'D') == true)
    {
        cout<<"Edge Found."<<endl;
    }
    else
    {
        cout<<"Edge not Found."<<endl;
    }
    
    


    return 0;
}
