#include <iostream>
#include"binarysearchtree.cpp"

using namespace std;

int main()
{
    TreeType<int> tree;

    
    tree.InsertItem(9);
    tree.InsertItem(113);
    tree.InsertItem(25);
    tree.InsertItem(98);
    tree.InsertItem(44);
    tree.InsertItem(94);
    tree.InsertItem(78);
    tree.InsertItem(82);
    tree.InsertItem(4);
    tree.InsertItem(110);
    return 0;
}
